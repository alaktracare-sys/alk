// Plain JavaScript version (no React).
// <div class="player" style="position:relative"> <canvas id="shapes" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none"></canvas> ...player UI... </div>
// randomShapes(document.getElementById('shapes'), { baseUrl: '/shapes', colors: ['#ff9a8b','#ffd27f'] });
async function randomShapes(canvas, o = {}) {
  const base = o.baseUrl || '/shapes', colors = o.colors || ['#ff9a8b', '#ffd27f', '#9fd8ff', '#c3a6ff', '#ffffff'];
  const mode = o.mode || 'mix', count = o.count || [28, 48], sizeFrac = o.sizeFrac || [0.10, 0.28], op = o.opacity || [0.6, 1];
  const j = await (await fetch(base + '/shapes.json')).json();
  const img = await new Promise(r => { const i = new Image(); i.onload = () => r(i); i.src = base + '/atlas.png'; });
  const dpr = window.devicePixelRatio || 1, W = canvas.width = canvas.clientWidth * dpr, H = canvas.height = canvas.clientHeight * dpr;
  const x = canvas.getContext('2d'), rnd = (a, b) => a + Math.random() * (b - a), tc = document.createElement('canvas');
  const n = Math.floor(rnd(count[0], count[1] + 1));
  for (let i = 0; i < n; i++) {
    const s = j.shapes[Math.floor(Math.random() * j.shapes.length)];
    const solid = mode === 'solid' || (mode === 'mix' && Math.random() < 0.5), sx = s.x + (solid ? s.w + 2 : 0);
    const k = rnd(sizeFrac[0], sizeFrac[1]) * W / Math.max(s.w, s.h), dw = Math.max(2, Math.round(s.w * k)), dh = Math.max(2, Math.round(s.h * k));
    tc.width = dw; tc.height = dh; const t = tc.getContext('2d');
    t.drawImage(img, sx, s.y, s.w, s.h, 0, 0, dw, dh);
    t.globalCompositeOperation = 'source-in'; t.fillStyle = colors[Math.floor(Math.random() * colors.length)]; t.fillRect(0, 0, dw, dh);
    x.save(); x.globalAlpha = rnd(op[0], op[1]); x.translate(rnd(0, W), rnd(0, H)); if (Math.random() > .5) x.rotate(rnd(-1.2, 1.2));
    x.drawImage(tc, -dw / 2, -dh / 2); x.restore();
  }
}
