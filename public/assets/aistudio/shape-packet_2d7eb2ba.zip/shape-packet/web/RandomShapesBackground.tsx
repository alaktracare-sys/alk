import React, { useEffect, useRef } from 'react';

// Place atlas.png and shapes.json in your public folder (e.g. /public/shapes/).
type Props = {
  baseUrl?: string;                 // folder that holds atlas.png + shapes.json
  colors?: string[];                // e.g. colours taken from the album art
  count?: [number, number];         // min/max number of shapes
  sizeFrac?: [number, number];      // shape size as a fraction of the width
  opacity?: [number, number];
  mode?: 'mix' | 'hollow' | 'solid';
  rotate?: boolean;
  seed?: number;                    // change this number to reshuffle
  className?: string;
};

export default function RandomShapesBackground({
  baseUrl = '/shapes', colors = ['#ff9a8b', '#ffd27f', '#9fd8ff', '#c3a6ff', '#ffffff'],
  count = [28, 48], sizeFrac = [0.10, 0.28], opacity = [0.6, 1], mode = 'mix',
  rotate = true, seed = 0, className,
}: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const data = useRef<{ img: HTMLImageElement; shapes: any[] } | null>(null);

  const draw = () => {
    const c = ref.current, d = data.current;
    if (!c || !d) return;
    const dpr = window.devicePixelRatio || 1;
    const W = c.clientWidth * dpr, H = c.clientHeight * dpr;
    c.width = W; c.height = H;
    const x = c.getContext('2d')!;
    const rnd = (a: number, b: number) => a + Math.random() * (b - a);
    const n = Math.floor(rnd(count[0], count[1] + 1));
    const tc = document.createElement('canvas');
    for (let i = 0; i < n; i++) {
      const s = d.shapes[Math.floor(Math.random() * d.shapes.length)];
      const solid = mode === 'solid' || (mode === 'mix' && Math.random() < 0.5);
      const sx = s.x + (solid ? s.w + 2 : 0);
      const k = (rnd(sizeFrac[0], sizeFrac[1]) * W) / Math.max(s.w, s.h);
      const dw = Math.max(2, Math.round(s.w * k)), dh = Math.max(2, Math.round(s.h * k));
      tc.width = dw; tc.height = dh;
      const t = tc.getContext('2d')!;
      t.clearRect(0, 0, dw, dh);
      t.drawImage(d.img, sx, s.y, s.w, s.h, 0, 0, dw, dh);
      t.globalCompositeOperation = 'source-in';
      t.fillStyle = colors[Math.floor(Math.random() * colors.length)];
      t.fillRect(0, 0, dw, dh);
      x.save();
      x.globalAlpha = rnd(opacity[0], opacity[1]);
      x.translate(rnd(0, W), rnd(0, H));
      if (rotate && Math.random() > 0.5) x.rotate(rnd(-1.2, 1.2));
      x.drawImage(tc, -dw / 2, -dh / 2);
      x.restore();
    }
  };

  useEffect(() => {
    let dead = false;
    Promise.all([
      fetch(`${baseUrl}/shapes.json`).then(r => r.json()),
      new Promise<HTMLImageElement>(res => { const i = new Image(); i.onload = () => res(i); i.src = `${baseUrl}/atlas.png`; }),
    ]).then(([j, img]) => { if (dead) return; data.current = { img, shapes: j.shapes }; draw(); });
    return () => { dead = true; };
  }, [baseUrl]);

  useEffect(() => { draw(); }, [seed, mode, colors.join(',')]);

  return (
    <canvas ref={ref} className={className}
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 0 }} />
  );
}
