# Random Shapes Packet

295 doodle shapes (planets, moons, stars, sparkles, skulls, smileys, plants, hearts, lightning and more). Every shape comes in two versions: **hollow** (outline) and **solid** (filled). All are white with a transparent background, so the code tints them any colour. Crisp, not blurred.

## Folders
- `android/` – for your Jetpack Compose (Kotlin) app
  - `RandomShapesBackground.kt` – ready Composable
  - `assets/shapes/hollow/000-294.png` and `assets/shapes/solid/000-294.png` – the shapes
- `web/` – same thing for a web app (`atlas.png` + `shapes.json` + `RandomShapesBackground.tsx` + `random-shapes.js`)
- `preview.png` – picture of 150 of the shapes (solid versions)

## Android: set up
1. Copy the `assets/shapes` folder into `app/src/main/assets/shapes` (so the files are at `assets/shapes/hollow/000.png` etc.).
2. Put `RandomShapesBackground.kt` in your project and change the `package` line to yours.
3. Paste this prompt into AI Studio together with the files:

> I attached a shape packet for my Jetpack Compose music app. Add `RandomShapesBackground` as the bottom layer of the full-screen Now Playing / player screen (a Box where it is drawn first and the album art, title, seek bar and controls sit on top). It draws random shapes at random positions, sizes and rotations, a mix of hollow and solid, crisp and not blurred. Take its colours from the current album art (use androidx.palette; fall back to the default colours). Reshuffle by changing the `seed` parameter whenever the song changes, and add a small shuffle icon button on the player that reshuffles by hand. Keep the dark fade at the top and bottom so text stays readable. Do not change anything else in the app.

## Settings (parameters)
`mode` (MIX, HOLLOW, SOLID), `count` (28..48), `sizeFrac` (0.10f..0.28f of the screen width), `alphaRange`, `colors`, `rotate`, `seed`.
