package com.example.studiopp.ui.shapes   // <- change to your own package

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * Random shapes (hollow + solid) behind the player screen.
 * Shapes live in app/src/main/assets/shapes/hollow/000.png..294.png and shapes/solid/000.png..294.png
 * They are white + transparent, so they get tinted with the colours you pass in.
 * Change `seed` (for example the song id) to reshuffle.
 */
enum class ShapeMode { MIX, HOLLOW, SOLID }

private const val SHAPE_COUNT = 295
private val bitmapCache = HashMap<String, ImageBitmap>()

private data class PlacedShape(
    val image: ImageBitmap, val cx: Float, val cy: Float,
    val dw: Int, val dh: Int, val degrees: Float, val alpha: Float, val color: Color,
)

private fun loadShape(context: Context, solid: Boolean, id: Int): ImageBitmap {
    val path = "shapes/${if (solid) "solid" else "hollow"}/%03d.png".format(id)
    return bitmapCache.getOrPut(path) {
        context.assets.open(path).use { BitmapFactory.decodeStream(it).asImageBitmap() }
    }
}

private fun buildShapes(
    context: Context, size: IntSize, colors: List<Color>, mode: ShapeMode,
    count: IntRange, sizeFrac: ClosedFloatingPointRange<Float>,
    alphaRange: ClosedFloatingPointRange<Float>, rotate: Boolean,
): List<PlacedShape> {
    val r = Random(System.nanoTime())
    val n = r.nextInt(count.first, count.last + 1)
    return List(n) {
        val solid = mode == ShapeMode.SOLID || (mode == ShapeMode.MIX && r.nextBoolean())
        val img = loadShape(context, solid, r.nextInt(SHAPE_COUNT))
        val target = size.width * (sizeFrac.start + r.nextFloat() * (sizeFrac.endInclusive - sizeFrac.start))
        val k = target / maxOf(img.width, img.height)
        PlacedShape(
            image = img,
            cx = r.nextFloat() * size.width, cy = r.nextFloat() * size.height,
            dw = maxOf(2, (img.width * k).toInt()), dh = maxOf(2, (img.height * k).toInt()),
            degrees = if (rotate && r.nextBoolean()) (r.nextFloat() * 2f - 1f) * 70f else 0f,
            alpha = alphaRange.start + r.nextFloat() * (alphaRange.endInclusive - alphaRange.start),
            color = colors[r.nextInt(colors.size)],
        )
    }
}

@Composable
fun RandomShapesBackground(
    modifier: Modifier = Modifier,
    seed: Any = 0,
    colors: List<Color> = listOf(Color(0xFFFF9A8B), Color(0xFFFFD27F), Color(0xFF9FD8FF), Color(0xFFC3A6FF), Color.White),
    mode: ShapeMode = ShapeMode.MIX,
    count: IntRange = 28..48,
    sizeFrac: ClosedFloatingPointRange<Float> = 0.10f..0.28f,
    alphaRange: ClosedFloatingPointRange<Float> = 0.6f..1f,
    rotate: Boolean = true,
) {
    val context = LocalContext.current
    var size by remember { mutableStateOf(IntSize.Zero) }
    var placed by remember { mutableStateOf<List<PlacedShape>>(emptyList()) }

    LaunchedEffect(seed, mode, size, colors) {
        if (size.width == 0 || size.height == 0 || colors.isEmpty()) return@LaunchedEffect
        placed = withContext(Dispatchers.IO) {
            buildShapes(context, size, colors, mode, count, sizeFrac, alphaRange, rotate)
        }
    }

    Canvas(modifier.onSizeChanged { size = it }) {
        placed.forEach { p ->
            withTransform({ translate(p.cx, p.cy); rotate(p.degrees, Offset.Zero) }) {
                drawImage(
                    image = p.image,
                    dstOffset = IntOffset(-p.dw / 2, -p.dh / 2),
                    dstSize = IntSize(p.dw, p.dh),
                    alpha = p.alpha,
                    colorFilter = ColorFilter.tint(p.color),
                    filterQuality = FilterQuality.High,
                )
            }
        }
    }
}

/* Usage on the player screen:

Box(Modifier.fillMaxSize()) {
    RandomShapesBackground(
        modifier = Modifier.fillMaxSize(),
        seed = currentSong.id,                // new song -> new shapes
        colors = albumArtColors,              // optional, from album art (androidx.palette)
    )
    // ...your existing player UI (album art, title, seek bar, controls) on top...
}
*/
